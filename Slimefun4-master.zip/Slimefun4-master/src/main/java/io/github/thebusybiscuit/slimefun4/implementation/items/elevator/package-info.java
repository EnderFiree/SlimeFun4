/**
 * This package holds the {@link io.github.thebusybiscuit.slimefun4.implementation.items.elevator.ElevatorPlate} and any
 * related classes to making the elevator work.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.elevator; 