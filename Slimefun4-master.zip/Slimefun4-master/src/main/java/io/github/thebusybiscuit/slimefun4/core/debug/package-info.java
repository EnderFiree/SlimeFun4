/**
 * This package holds the debug functionality of Slimefun, these can be used as addons but are mostly just
 * going to be used by Slimefun itself.
 */
package io.github.thebusybiscuit.slimefun4.core.debug;