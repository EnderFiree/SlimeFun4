/**
 * This package holds classes related to
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.backpacks.SlimefunBackpack}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.backpacks;