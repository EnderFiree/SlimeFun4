/**
 * This package contains a few classes that revolve around the API for
 * {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}, such as
 * {@link io.github.thebusybiscuit.slimefun4.api.items.ItemSetting}
 */
package io.github.thebusybiscuit.slimefun4.api.items;