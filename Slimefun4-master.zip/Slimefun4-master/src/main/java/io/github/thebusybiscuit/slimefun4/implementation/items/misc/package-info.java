/**
 * This package holds any miscellaneous {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 * implementations.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.misc;