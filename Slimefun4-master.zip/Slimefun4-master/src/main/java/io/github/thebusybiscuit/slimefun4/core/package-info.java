/**
 * This package holds the core systems of Slimefun, these are not necessarily used as an API
 * but rather provide the core functionality of this {@link org.bukkit.plugin.Plugin}.
 */
package io.github.thebusybiscuit.slimefun4.core;