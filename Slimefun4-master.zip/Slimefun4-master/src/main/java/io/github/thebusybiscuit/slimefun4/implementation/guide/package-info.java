/**
 * This package provides the different implementations of our
 * {@link io.github.thebusybiscuit.slimefun4.core.guide.SlimefunGuide}
 */
package io.github.thebusybiscuit.slimefun4.implementation.guide;