/**
 * This package contains various sub classes of {@link io.github.thebusybiscuit.slimefun4.api.items.ItemSetting}.
 */
package io.github.thebusybiscuit.slimefun4.api.items.settings;