/**
 * This package holds the {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem} implementations related to
 * the {@link io.github.thebusybiscuit.slimefun4.implementation.items.altar.AncientAltar}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.altar;