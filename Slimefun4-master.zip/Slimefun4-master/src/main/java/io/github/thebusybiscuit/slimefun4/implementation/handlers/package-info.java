/**
 * This package holds simple implementations of {@link io.github.thebusybiscuit.slimefun4.api.items.ItemHandler}.
 * These are just handlers that can be re-used frequently.
 */
package io.github.thebusybiscuit.slimefun4.implementation.handlers;