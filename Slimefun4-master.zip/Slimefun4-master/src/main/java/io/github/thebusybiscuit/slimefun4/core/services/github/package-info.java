/**
 * This package contains everything related to GitHub and contributors.
 */
package io.github.thebusybiscuit.slimefun4.core.services.github;