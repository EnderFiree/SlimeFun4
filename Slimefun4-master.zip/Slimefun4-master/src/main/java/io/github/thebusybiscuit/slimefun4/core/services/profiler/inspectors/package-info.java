/**
 * This package holds the different implementations of
 * {@link io.github.thebusybiscuit.slimefun4.core.services.profiler.PerformanceInspector}.
 */
package io.github.thebusybiscuit.slimefun4.core.services.profiler.inspectors;