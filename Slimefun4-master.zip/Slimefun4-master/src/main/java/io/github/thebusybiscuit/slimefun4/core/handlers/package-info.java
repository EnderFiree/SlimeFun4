/**
 * This package contains all variations of {@link io.github.thebusybiscuit.slimefun4.api.items.ItemHandler} that
 * can be assigned to a {@link io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem}
 */
package io.github.thebusybiscuit.slimefun4.core.handlers;