/**
 * This package provides a few "Services" that Slimefun uses.
 * These services can be considered like a black box, you put stuff in or just let them run,
 * they work independently.
 */
package io.github.thebusybiscuit.slimefun4.core.services;