/**
 * This package contains any electric machines related to {@link org.bukkit.entity.Entity} interactions, most notably
 * the
 * {@link io.github.thebusybiscuit.slimefun4.implementation.items.electric.machines.entities.AbstractEntityAssembler}.
 */
package io.github.thebusybiscuit.slimefun4.implementation.items.electric.machines.entities;