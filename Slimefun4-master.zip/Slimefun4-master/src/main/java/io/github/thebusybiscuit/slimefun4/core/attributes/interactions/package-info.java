/**
 * This package contains the various possible {@link io.github.thebusybiscuit.slimefun4.core.attributes.interactions.InteractionResult}s
 * that can be returned by an {@link io.github.thebusybiscuit.slimefun4.core.attributes.ExternallyInteractable} object.
 */
package io.github.thebusybiscuit.slimefun4.core.attributes.interactions;