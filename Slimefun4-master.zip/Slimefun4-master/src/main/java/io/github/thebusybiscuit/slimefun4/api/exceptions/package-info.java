/**
 * This package contains all different extensions of {@link java.lang.Exception} that Slimefun
 * uses internally.
 */
package io.github.thebusybiscuit.slimefun4.api.exceptions;